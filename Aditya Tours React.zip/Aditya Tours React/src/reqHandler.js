import axios from 'axios';
axios.defaults.withCredentials = true


const postHandler = async (url,data) =>{
    try {
        const resp = await axios.post(url,data,{withCredentials:true});
        return resp.data;
    } catch (error) {
        console.log(error);
    }
   
}


const getHandler = async (url) =>{
    try {
        const resp = await axios.get(url,{withCredentials:true});
        return resp.data;
    } catch (error) {
        console.log(error);
    }
   
}

const patchHandler = async (url,data) =>{
    try {
        const resp = await axios.patch(url,data,{withCredentials:true});
        return resp.data;
    } catch (error) {
        console.log(error);
    }
   
}

const deleteHandler = async (url,data) =>{
    try {
        const resp = await axios.delete(url,{withCredentials:true});
        return resp.data;
    } catch (error) {
        console.log(error);
    }
   
}


export {postHandler,getHandler,patchHandler,deleteHandler};