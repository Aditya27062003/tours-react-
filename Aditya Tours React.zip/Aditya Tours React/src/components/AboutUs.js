import "./AboutUsStyles.css";

import React from 'react'

function AboutUs() {
  return (
    <div className="about-container">
        <h1>Our History</h1>
        <p>Water is the most important and precious element
             for the existence of life on this planet. 
             We should respect the value of water in our life and 
             save it from being polluted. We should aware and 
             motivate people about the importance of water as 
             well as water saving techniques from pollution.
        </p>

        <h1>Our Mission</h1>
        <p>Water is the most important and precious element
             for the existence of life on this planet. 
             We should respect the value of water in our life and 
             save it from being polluted. We should aware and 
             motivate people about the importance of water as 
             well as water saving techniques from pollution.
        </p>

        <h1>Our Vision</h1>
        <p>Water is the most important and precious element
             for the existence of life on this planet. 
             We should respect the value of water in our life and 
             save it from being polluted. We should aware and 
             motivate people about the importance of water as 
             well as water saving techniques from pollution.
        </p>
    </div>
  )
}

export default AboutUs;