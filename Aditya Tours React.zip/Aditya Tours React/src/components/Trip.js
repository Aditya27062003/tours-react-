import React from "react";
import "./TripStyles.css";
import TripData from "./TripData";
import Trip1 from "../assets/5.jpg";
import Trip2 from "../assets/8.jpg";
import Trip3 from "../assets/6.jpg";
function Trip() {
  return (
    <>
      <div className="trip">
        <h1>Recent Trips</h1>
        <p>You can discover unique destinations using Google maps</p>
        <div className="tripcard">
          <TripData
            image={Trip1}
            heading="Trip in Indonesia"
            text="As the world's third largest 
            democracy, Indonesia is a presidential republic with an elected legislature. It has 38 provinces, of which nine have special status. The country's capital, Jakarta, is the world's second-most populous urban area. 
            Indonesia shares land borders with Papua New Guinea, East Timor, and the eastern part of Malaysia, as well as maritime borders with Singapore, Vietnam, Thailand, the Philippines, Australia, Palau, and India. 
            Despite its large population and densely populated regions, Indonesia has vast areas of wilderness that support one of the world's highest level of biodiversity."
          />
          <TripData
            image={Trip2}
            heading="Trip in India"
            text="As the world's third largest 
            democracy, Indonesia is a presidential republic with an elected legislature. It has 38 provinces, of which nine have special status. The country's capital, Jakarta, is the world's second-most populous urban area. 
            Indonesia shares land borders with Papua New Guinea, East Timor, and the eastern part of Malaysia, as well as maritime borders with Singapore, Vietnam, Thailand, the Philippines, Australia, Palau, and India. 
            Despite its large population and densely populated regions, Indonesia has vast areas of wilderness that support one of the world's highest level of biodiversity."
          />
          <TripData
            image={Trip3}
            heading="Trip in Africa"
            text="As the world's third largest 
            democracy, Indonesia is a presidential republic with an elected legislature. It has 38 provinces, of which nine have special status. The country's capital, Jakarta, is the world's second-most populous urban area. 
            Indonesia shares land borders with Papua New Guinea, East Timor, and the eastern part of Malaysia, as well as maritime borders with Singapore, Vietnam, Thailand, the Philippines, Australia, Palau, and India. 
            Despite its large population and densely populated regions, Indonesia has vast areas of wilderness that support one of the world's highest level of biodiversity."
          />
        </div>
      </div>
    </>
  );
}

export default Trip;
